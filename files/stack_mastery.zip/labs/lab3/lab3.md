# Lab 3: Building blocks

## Lab duration

20 minutes


## Overview

Leading up to this lab, we covered the following concepts in the workshop:

* Using AWS CloudFormation intrinsic functions
* Reducing code complexity by using `Fn::Sub`
* Configuring servers by using `cfn-init`

In this lab you will improve the structure and readability of your templates by using `Fn::Sub` and `cfn-init`.


## Objectives

1. Convert `Fn::Join` functions to `Fn::Sub` functions
2. Add a Metadata section for `cfn-init` and include:
   * `AWS::CloudFormation::Authentication`
   * `AWS::CloudFormation::Init`
   * Relative paths using `Fn::Sub`


## Tasks

### Getting started

1. If you deployed the stack for Lab 2, delete it now. In the AWS CloudFormation console, choose the stack, choose **Actions**, and then choose **Delete Stack**.
2. Review any updates or announcements in the dashboard. You will see that the final files for Lab 2 are now available for you to review.
3. Download the `lab3-initial.zip` file, which contains the assets to start this lab.
4. Extract the zip file and open the extracted templates (both the master template and the `templates` directory) in your favorite text editor.

Here are the individual tasks.


### Task 1: Convert `Fn::Join` functions to `Fn::Sub` functions

For this task, you will find the complex `Fn::Join` operations in your templates and replace them with `Fn::Sub` functions. As you modify each template, you can use the `validate-template` command in the AWS CLI or the `Test-CFNTemplate` cmdlet in the AWS Tools for Windows PowerShell, to validate that you're using the correct syntax:
1. Make sure you have the [AWS CLI installed](http://docs.aws.amazon.com/cli/latest/userguide/installing.html) or [AWS Tools for Windows PowerShell installed](http://docs.aws.amazon.com/powershell/latest/userguide/pstools-getting-set-up.html).
2. Get the credentials from the dashboard by choosing the **AWS Console** button.
3. Validate your template. For example:

  * To validate a template by using the AWS CLI, run the export commands locally, and ensure that no errors are returned when you run:  
  `aws cloudformation validate-template --region eu-central-1 --template-body file:///<PATH-TO>/webserver.yaml`
  * To validate a template by using the AWS PowerShell module, ensure that no errors are returned when you run:  
  `Test-CFNTemplate -AccessKey <ACCESSKEY> -SecretKey <SECRETKEY> -SessionToken <SESSIONTOKEN> -Region eu-central-1 -TemplateBody (Get-Content -Raw C:\<PATH-TO>\webserver.yaml)`

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-join.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-join.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-sub.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-sub.html)

### Task 2: Add a `Metadata:` section for `cfn-init`

For this task, you will turn the commands from the `UserData:` section used to bootstrap your web server instance into more structured `cfn-init` in a new `Metadata:` section of the resource. This will include permissions to access S3 objects, install packages, and write new files. Validate the metadata by using the `validate-template` command in AWS CLI or the `Test-CFNTemplate` cmdlet in PowerShell, as explained above.

**Here's a hint to get started**: The index page has been moved to a file in the `scripts` directory where you can reference it via a URL that's similar to how templates are referenced for nested stacks.

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-authentication.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-authentication.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-init.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-init.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-init.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-init.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-signal.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-signal.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-creationpolicy.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-creationpolicy.html)


## Next steps

If you run into issues, work with your group to troubleshoot. Lab assistants are available if you get stuck.
