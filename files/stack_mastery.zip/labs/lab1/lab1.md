# Lab 1: Low hanging fruit

## Lab Duration

30 minutes


## Overview

Leading up to this lab, we covered the following concepts in the workshop:

* Parameter validation
* Parameter types
* Parameter groups
* Parameter labels
* Template constraints (rules)
* AMI mappings

This lab provides hands-on experience with the above concepts. You will use your favorite text editor (e.g. Atom, VSCode, Sublime) to modify the starting template by adding sections, changing properties, until ultimately ending up with a deployable template.

The starting template you will be using is a monolithic and pared down version of the [Magento Quick Start reference deployment](https://aws.amazon.com/quickstart/architecture/magento/). It actually doesn't install Magento and omits several other concepts that we will explore in later labs. This template, which we have nicknamed “*fauxgento*”, is much quicker to deploy within the time constraints of these labs, but still provides you with the opportunity to put into practice the above concepts.


## Objectives

1. Create an AMI mappings section
2. Add template rules (constraints)
3. Limit parameters to allowed values
4. Extra credit: Create groups and labels


## Tasks

### Getting started

#### Retrieve Lab 1 assets
1. In your browser, navigate to the workshop dashboard at [https://dashboard.staging.awsgameday.io](https://dashboard.staging.awsgameday.io/).
2. Input the hash that's printed on the index card you were provided. The dashboard provides you with the credentials and a federated link to access the AWS console for this workshop.  This is an AWS account we will be providing you, so you will not have to use your own.
3. Start by downloading the `lab1-initial.zip` file which contains the assets to start this lab.
4. Extract the zip file and open the `fauxgento-lab1-initial.yaml` template file in your favorite text editor.

#### Create an Amazon EC2 Key Pair
1. Select the **AWS Console** button in the dashboard, then select the **Open Console** button. This will open a new tab/window with the AWS console.
2. Since we will be working in the `eu-central-1` EU (Frankfurt) region for this workshop, select **EU (Frankfurt)** from the top right of the console.   As you go through the lab, if you ever encounter any permissions errors, verify that you are in the **EU (Frankfurt)** region.
3. Go to the **EC2** console by searching or selecting it from the list of AWS services.
4. Select **Key Pairs** from the left pane in the EC2 console.
5. Select the **Create Key Pair** button.
6. Type a name that you can remember later on. Something like `workshop` will do.
7. Save the private key `.pem` file locally to place you can refer to later, as needed.
8. Once you have the file saved locally, you will need to set the permissions correctly in order to use the keypair.  For example `chmod 400 mykeypair.pem`.  For more information, see the documentation [here](http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-key-pairs.html)


The individual tasks are explained below:


### Task 1: Create an AMI mappings section

For this task, you will create a `Mappings:` section at the top level of the template. Mappings typically sit between the `Parameters:` and `Conditions:` sections of the template.  Add support for the deployment of this CloudFormation template in different regions by mapping the [AMI (Amazon Machine Image)](http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AMIs.html) that corresponds to each respective region. Here is a working set of [Amazon Linux](https://aws.amazon.com/amazon-linux-ami/) AMIs for each region:

**AMI full name:** `amzn-ami-hvm-2017.09.1.20171103-x86_64-gp2`  
**AMI short name:** `AMZNLINUXHVM`

|      AWS Region      |       AMI ID       |
|----------------------|--------------------|
|    ap-northeast-1    |    ami-2803ac4e    |
|    ap-northeast-2    |    ami-fc862292    |
|      ap-south-1      |    ami-2ed19c41    |
|    ap-southeast-1    |    ami-dd7935be    |
| **_ap-southeast-2_** | **_ami-1a668878_** |
|     ca-central-1     |    ami-ef3b838b    |
|  **_eu-central-1_**  | **_ami-e28d098d_** |
|   **_eu-west-1_**    | **_ami-760aaa0f_** |
|      eu-west-2       |    ami-e3051987    |
|      sa-east-1       |    ami-1678037a    |
|   **_us-east-1_**    | **_ami-6057e21a_** |
|   **_us-east-2_**    | **_ami-aa1b34cf_** |
|      us-west-1       |    ami-1a033c7a    |
|   **_us-west-2_**    | **_ami-32d8124a_** |


Pick at least 3 of the **_bold-italic_** regions from the table above to include in your new AMI mappings section. Make sure that you include `eu-central-1` as part of your chosen regions for the AMI map.

**Resources:**  
Here is the CloudFormation documentation to assist with the proper syntax and construction for mappings.  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/mappings-section-structure.html  ](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/mappings-section-structure.html  )


### Task 2: Add template rules (constraints)

For this task, you will add a `Rules:` section to the template to set deployment constraints. Specifically, you will add a rule to prevent the template from being deployed outside particular AWS regions. Configure the rule to only allow the stack to be created if the deployment region (hint: `AWS::Region`) matches those from your AMI mapping from Task 1.

**Resources:**  
Here is the CloudFormation documentation for guidance on rule and assertion syntax.  
[http://docs.aws.amazon.com/servicecatalog/latest/adminguide/reference-template_constraint_rules.html  ](http://docs.aws.amazon.com/servicecatalog/latest/adminguide/reference-template_constraint_rules.html  )



### Task 3: Limit parameters to allowed values

For this task, you will add allowed values to parameters that have predictable options.  Focus on selecting the correct parameter type and properties to only accept valid values. Think of things like instance types, boolean, and other parameter values that can be grouped into a list of choices.

**Resources:**  
Here is the CloudFormation documentation for Parameters including input types and constraining properties.  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/parameters-section-structure.html  ](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/parameters-section-structure.html  )


### Task 4: Parameter groups and labels

For this task, create a `Metadata:` section at the top level of the template. Inside that metadata section, you will add an `AWS::CloudFormation::Interface` key that defines the parameter groups and labels of the CloudFormation template. Organize the parameter groups in relevant categories and include parameter labels that make the parameter names more readable.

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudformation-interface.html  ](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudformation-interface.html  )


## Next Steps

Try deploying the template in the `eu-central-1` EU (Frankfurt) region. Also, try deploying your stack in a region you don't allow to validate that your template constraints are functioning properly.  Go to the AWS CloudFormation console to get started. If you run into issues, work with your group to troubleshoot.  Lab assistants are available if you get stuck.
