# Lab 2: Stackception

## Lab duration

10 minutes


## Overview

Leading up to this lab, we covered the following concepts in the workshop:

* Breaking apart monolithic templates (decomposition)
* Stack nesting
* Resource naming strategies

In this lab you will move away from the monolithic *fauxgento* template in Lab 1 and start working with a master template that deploys nested CloudFormation stacks from a reusable set of templates.


## Objectives

1. Familiarize yourself with the master template and nested stack architecture.
2. Complete the master template that orchestrates the entire deployment and sub-stacks.



## Tasks

### Getting started

1. Start by deleting the stack you deployed in Lab 1. In the AWS CloudFormation console, choose the stack, choose **Actions**, and then choose **Delete Stack**.
2. Review any updates or announcements in the dashboard. You will see that the final files for Lab 1 are now available for you to review.
3. Download the `lab2-initial.zip` file, which contains the assets to start this lab.
4. Extract the zip file and open the `fauxgento-lab2-master-initial.yaml` template file in your favorite text editor.

Here are the individual tasks.


### Task 1: Examine the master template

For this task, examine the `Resources:` section of the master template (`fauxgento-lab2-master-initial.yaml`). This template replaces all the AWS resources from the monolithic template with three `AWS::CloudFormation::Stack` resources for each of the three decomposed sections of our architecture: the VPC, the bastion hosts, and the Magento application architecture.

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-stack.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-stack.html)

### Task 2: Construct the template URLs

Now that you are familiar with the master template, construct the URLs for AWS CloudFormation to retrieve and create the sub-stacks. The template files are located in an S3 bucket that is not in your account. However, you will find the URLs for the templates listed in your dashboard, and you can use these to construct the URLs for the sub-stacks in your template.

## Next steps

Try deploying the nested stacks in the `eu-central-1` EU (Frankfurt) region. If you run into issues, work with your group to troubleshoot. Lab assistants are available if you get stuck.
