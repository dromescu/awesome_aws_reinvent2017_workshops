# Lab 4: Enhance

## Lab duration

20 minutes


## Overview

In the previous three labs, we focused on AWS CloudFormation-specific features and components. However, in our discussions, we also covered some architectural changes that will increase the resiliency and scalability of our application. These concepts include:

* Moving from a single instance to an [Auto Scaling group](http://docs.aws.amazon.com/autoscaling/latest/userguide/AutoScalingGroup.html)
* Using [Elastic Load Balancing](https://aws.amazon.com/elasticloadbalancing/)
* Switching out our MySQL Amazon EC2 instance to use a managed service: [Amazon Aurora](https://aws.amazon.com/rds/aurora/) for MySQL
* Replacing our NFS servers with [Amazon Elastic File System (Amazon EFS)](https://aws.amazon.com/efs/)

We're covering these resources specifically to demonstrate the breadth of services you can configure by using AWS CloudFormation, and how you should always think about ways to improve your architecture.

## Objectives

1. Convert the single web server instance to an Auto Scaling group that's backed by a launch configuration
2. Review the other changes made for you:
   * Elastic Load Balancing
   * Amazon Aurora
   * Amazon EFS


## Tasks

### Getting started

1. If you deployed the stack for Lab 3, delete it now. In the AWS CloudFormation console, choose the stack, choose **Actions**, and then choose **Delete Stack**.
2. Review any updates or announcements in the dashboard. You will see that the final files for Lab 3 are now available for you to review.
3. Download the `lab4-initial.zip` file, which contains the assets to start this lab.
4. Extract the zip file and open the extracted templates (both the master template and the `templates` directory) in your favorite text editor.

Here are the individual tasks.


### Task 1: Switch from a single instance to an Auto Scaling group

Previously, we were using a single instance to act as our web server. However, this doesn't adhere to best practices because our application cannot easily scale, nor does it offer us any protection in the event of a failure. To improve our application, we need to migrate this instance to an Auto Scaling group.

As you implement this feature, think about how you can continue to make your template flexible by using some of the lessons learned in previous labs; for example, by using parameters.

Validate your templates by using the `validate-template` command in AWS CLI or the `Test-CFNTemplate` cmdlet in PowerShell, as explained in Lab 3.

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-as-launchconfig.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-as-launchconfig.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-as-group.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-as-group.html)

### Task 2: Review the additional changes

To expedite this process, we've made a number of changes to the templates to take advantage of AWS managed services. Here are links to the templates and line numbers, so you can review how to write the AWS CloudFormation resources and stitch everything together:

1. Elastic Load Balancing -> [webserver.yaml](https://s3-us-west-2.amazonaws.com/cfnworkshop-assets-staging/workshops/stack-mastery/labs/lab4/initial/templates/webserver.yaml) -> Lines 196-222
   * In these templates, we've implemented this via a [Classic Load Balancer](http://docs.aws.amazon.com/elasticloadbalancing/latest/classic/introduction.html) with a **TargetTrackingScaling** policy. However if you look at the Magento Quick Start, you'll see that we've implemented it via the [Application Load Balancer](http://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html) instead, which affords additional functionality. Check it out in [webserver.template](https://github.com/aws-quickstart/quickstart-magento/blob/master/templates/webserver.template#L572) on lines 572-653.
2. Amazon Aurora -> You can see this change in the Magento Quick Start, in [rdsaurora.template](https://github.com/aws-quickstart/quickstart-magento/blob/master/templates/rdsaurora.template).
3. Amazon EFS -> [webserver.yaml](https://s3-us-west-2.amazonaws.com/cfnworkshop-assets-staging/workshops/stack-mastery/labs/lab4/initial/templates/webserver.yaml) -> Lines 168-195

**Resources:**  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ec2-elb.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ec2-elb.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rds-dbcluster.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rds-dbcluster.html)  
[http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-efs-filesystem.html](http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-efs-filesystem.html)  



## Next steps

If you run into issues, work with your group to troubleshoot. Lab assistants are available if you get stuck.

Finally, check out the dashboard for all the final assets for each lab. Feel free to download them and review at home!
